import { useAppStore } from '../store';
import { Mail, IdCard, Award, Phone, Instagram, Facebook, Youtube, LogOut } from 'lucide-react';
import { motion } from 'motion/react';

export const Profile = () => {
  const { user, progress, lessons, logout } = useAppStore();

  if (!user) return null;

  const totalLessons = lessons.filter(l => l.status === 'active').length;
  const progressPercent = Math.round((progress.length / (totalLessons || 1)) * 100) || 0;

  return (
    <div className="p-6 md:p-10 max-w-2xl mx-auto space-y-6 min-h-screen text-gray-100">
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-xl rounded-[2rem] p-8 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)] text-center relative overflow-hidden"
      >
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-1/2 bg-gradient-to-b from-emerald-500/10 to-transparent pointer-events-none" />
        
        <div className="w-28 h-28 mx-auto rounded-[2rem] bg-gradient-to-tr from-emerald-400 to-teal-500 p-[3px] shadow-[0_0_30px_rgba(16,185,129,0.3)] rotate-3">
          <div className="w-full h-full bg-gray-900 rounded-[1.8rem] flex items-center justify-center -rotate-3 overflow-hidden border border-white/10">
            <span className="text-4xl font-bold text-white uppercase">{user.name.charAt(0)}</span>
          </div>
        </div>

        <h2 className="mt-6 text-2xl font-bold text-white">{user.name}</h2>
        <div className="flex flex-wrap justify-center gap-2 mt-3">
          <span className="flex items-center gap-1.5 bg-black/40 px-3 py-1.5 rounded-lg border border-white/5 text-sm text-gray-300">
            <IdCard className="w-4 h-4 text-emerald-400" /> {user.studentId}
          </span>
          <span className="flex items-center gap-1.5 bg-black/40 px-3 py-1.5 rounded-lg border border-white/5 text-sm text-gray-300">
            <Mail className="w-4 h-4 text-emerald-400" /> {user.email}
          </span>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white/5 backdrop-blur-xl rounded-[2rem] p-6 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]"
      >
        <h3 className="text-lg font-bold mb-6 flex items-center gap-2 text-white">
          <Award className="w-5 h-5 text-emerald-400" /> Your Progress
        </h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400 font-medium">Course Completion</span>
              <span className="text-emerald-400 font-bold">{progressPercent}%</span>
            </div>
            <div className="w-full bg-black/40 rounded-full h-3 border border-white/5 overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full relative" style={{ width: `${progressPercent}%` }}>
                <div className="absolute inset-0 bg-white/20 animate-pulse" />
              </div>
            </div>
          </div>
          <div className="bg-black/20 rounded-xl p-4 border border-white/5 flex justify-between items-center">
            <span className="text-gray-300 font-medium">Lessons Completed</span>
            <span className="text-xl font-bold text-white">{progress.length} <span className="text-sm text-gray-500">/ {totalLessons}</span></span>
          </div>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white/5 backdrop-blur-xl rounded-[2rem] p-6 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]"
      >
        <h3 className="text-lg font-bold mb-6 text-white text-center">Connect With Us</h3>
        
        <div className="grid grid-cols-4 gap-4 mb-6">
          <a href="http://instagram.com/organic_mushroom_farm_jabalpur" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-500 to-purple-500 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
              <Instagram className="w-5 h-5" />
            </div>
          </a>
          <a href="https://www.facebook.com/@organic.mushroom.farm0/" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
              <Facebook className="w-5 h-5" />
            </div>
          </a>
          <a href="https://m.youtube.com/@organicmushroomfarm" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-full bg-red-600 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
              <Youtube className="w-5 h-5" />
            </div>
          </a>
          <a href="https://www.pinterest.com/organicmushroomfarm/" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 group">
            <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
              {/* Pinterest icon approximation */}
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.951-7.252 4.168 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.367 18.633 0 12.017 0z"/>
              </svg>
            </div>
          </a>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <a href="tel:9203544140" className="bg-black/20 hover:bg-black/40 rounded-xl p-4 border border-white/5 flex flex-col items-center justify-center gap-2 transition-colors text-center">
            <Phone className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-bold text-white">Call Support</span>
          </a>
          <a href="mailto:sonib491@gmail.com" className="bg-black/20 hover:bg-black/40 rounded-xl p-4 border border-white/5 flex flex-col items-center justify-center gap-2 transition-colors text-center">
            <Mail className="w-5 h-5 text-amber-400" />
            <span className="text-xs font-bold text-white">Email Us</span>
          </a>
        </div>
      </motion.div>

      <motion.button 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        onClick={logout}
        className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-[1.5rem] py-4 flex items-center justify-center gap-2 font-bold transition-all shadow-lg"
      >
        <LogOut className="w-5 h-5" />
        Sign Out
      </motion.button>
      
    </div>
  );
};
