import { useState, useEffect } from 'react';
import { useAppStore } from '../store';
import { Users, BookOpen, FileText, Bot, Activity, CheckCircle, Save, LogOut } from 'lucide-react';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router';

export const AdminDashboard = () => {
  const { user, lessons, updateLesson, logout } = useAppStore();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'users' | 'videos' | 'pdfs' | 'ai'>('users');
  const [allUsers, setAllUsers] = useState<any[]>([]);

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
    }
  }, [user, navigate]);

  useEffect(() => {
    const usersStr = localStorage.getItem('omf_users');
    if (usersStr) {
      setAllUsers(JSON.parse(usersStr));
    }
  }, []);

  const totalLessons = lessons.length;
  const activeUsers = allUsers.length;
  
  if (!user || user.role !== 'admin') return null;

  return (
    <div className="p-6 md:p-10 max-w-6xl mx-auto space-y-6 min-h-screen text-gray-100 pb-32">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-emerald-400 font-medium">Platform Management Control</p>
        </div>
        <button 
          onClick={logout}
          className="bg-red-500/20 text-red-400 p-3 rounded-xl hover:bg-red-500/30 transition-all border border-red-500/30 flex items-center gap-2"
        >
          <LogOut className="w-5 h-5" /> <span className="hidden sm:inline">Logout</span>
        </button>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white/5 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-lg">
          <div className="flex items-center gap-3 text-emerald-400 mb-2">
            <Users className="w-5 h-5" />
            <span className="text-sm font-bold">Total Users</span>
          </div>
          <p className="text-3xl font-bold text-white">{activeUsers}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-lg">
          <div className="flex items-center gap-3 text-blue-400 mb-2">
            <Activity className="w-5 h-5" />
            <span className="text-sm font-bold">Active Sessions</span>
          </div>
          <p className="text-3xl font-bold text-white">{Math.max(1, Math.floor(activeUsers * 0.7))}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-lg">
          <div className="flex items-center gap-3 text-amber-400 mb-2">
            <BookOpen className="w-5 h-5" />
            <span className="text-sm font-bold">Total Lessons</span>
          </div>
          <p className="text-3xl font-bold text-white">{totalLessons}</p>
        </div>
        <div className="bg-white/5 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-lg">
          <div className="flex items-center gap-3 text-purple-400 mb-2">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-bold">Avg Progress</span>
          </div>
          <p className="text-3xl font-bold text-white">
            {activeUsers > 0 
              ? Math.round(allUsers.reduce((acc, u) => acc + (u.progress?.length || 0), 0) / activeUsers / totalLessons * 100) 
              : 0}%
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6 bg-black/20 p-1.5 rounded-2xl border border-white/5">
        {[
          { id: 'users', label: 'User Management', icon: <Users className="w-4 h-4" /> },
          { id: 'videos', label: 'Video Lessons', icon: <BookOpen className="w-4 h-4" /> },
          { id: 'pdfs', label: 'PDF Resources', icon: <FileText className="w-4 h-4" /> },
          { id: 'ai', label: 'AI Training', icon: <Bot className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm transition-all whitespace-nowrap flex-1 justify-center ${
              activeTab === tab.id 
                ? 'bg-emerald-500 text-white shadow-lg' 
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <motion.div 
        key={activeTab}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/5 backdrop-blur-xl rounded-[2rem] p-6 md:p-8 border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]"
      >
        {activeTab === 'users' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-white mb-4">Registered Users</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-gray-400">
                    <th className="pb-3 font-medium">Student ID</th>
                    <th className="pb-3 font-medium">Name</th>
                    <th className="pb-3 font-medium">Email</th>
                    <th className="pb-3 font-medium">Progress</th>
                    <th className="pb-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {allUsers.map((u, i) => (
                    <tr key={i} className="text-gray-200">
                      <td className="py-4 text-emerald-400 font-mono">{u.studentId}</td>
                      <td className="py-4 font-bold">{u.name}</td>
                      <td className="py-4">{u.email}</td>
                      <td className="py-4">
                        <div className="w-24 bg-black/40 rounded-full h-2 overflow-hidden border border-white/5">
                          <div 
                            className="bg-emerald-500 h-full" 
                            style={{ width: `${Math.round(((u.progress?.length || 0) / totalLessons) * 100)}%` }} 
                          />
                        </div>
                      </td>
                      <td className="py-4 text-right">
                        <button className="text-xs bg-red-500/20 text-red-400 px-3 py-1.5 rounded-lg hover:bg-red-500/40 transition-colors">
                          Block
                        </button>
                      </td>
                    </tr>
                  ))}
                  {allUsers.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-gray-500">No registered users yet.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'videos' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-white mb-4">Video Lesson Management</h2>
            <p className="text-sm text-gray-400 mb-6">Update Google Drive embedding links. To enable a lesson, set its status to "active".</p>
            
            <div className="space-y-4">
              {lessons.map(lesson => (
                <div key={lesson.id} className="bg-black/20 p-5 rounded-2xl border border-white/5 flex flex-col gap-4">
                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-emerald-400">{lesson.title}</h3>
                    <select 
                      value={lesson.status || 'coming-soon'}
                      onChange={(e) => updateLesson(lesson.id, { status: e.target.value as any })}
                      className="bg-gray-900 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none"
                    >
                      <option value="active">Active</option>
                      <option value="coming-soon">Coming Soon</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Google Drive Link (Embed)</label>
                    <input 
                      type="text" 
                      value={lesson.videoUrl || ''}
                      onChange={(e) => updateLesson(lesson.id, { videoUrl: e.target.value })}
                      placeholder="https://drive.google.com/file/d/.../preview"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'pdfs' && (
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-white mb-4">PDF Resource Management</h2>
            
            <div className="space-y-4">
              {lessons.map(lesson => (
                <div key={lesson.id} className="bg-black/20 p-5 rounded-2xl border border-white/5 flex flex-col gap-4">
                  <h3 className="font-bold text-amber-400">{lesson.title}</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-1">English Guide URL</label>
                      <input 
                        type="text" 
                        value={lesson.englishGuideUrl || ''}
                        onChange={(e) => updateLesson(lesson.id, { englishGuideUrl: e.target.value })}
                        className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Hindi Guide URL</label>
                      <input 
                        type="text" 
                        value={lesson.hindiGuideUrl || ''}
                        onChange={(e) => updateLesson(lesson.id, { hindiGuideUrl: e.target.value })}
                        className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">AI Assistant Training Panel</h2>
              <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-bold rounded-lg border border-emerald-500/30 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
                Gemini API Active
              </span>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-black/20 p-6 rounded-2xl border border-white/5 space-y-4 text-center border-dashed">
                <FileText className="w-10 h-10 text-gray-500 mx-auto" />
                <div>
                  <h3 className="font-bold text-gray-300">Upload Knowledge PDFs</h3>
                  <p className="text-xs text-gray-500 mt-1">Train the AI on new mushroom varieties, costs, and techniques.</p>
                </div>
                <button className="bg-white/10 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-white/20 transition-colors w-full">
                  Browse Files
                </button>
              </div>

              <div className="bg-black/20 p-6 rounded-2xl border border-white/5 space-y-4">
                <h3 className="font-bold text-gray-300">Add Q&A Pair manually</h3>
                <div className="space-y-3">
                  <input type="text" placeholder="Question..." className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm text-white" />
                  <textarea placeholder="Answer..." rows={3} className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm text-white resize-none"></textarea>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-blue-500 transition-colors w-full flex items-center justify-center gap-2">
                    <Save className="w-4 h-4" /> Save to Knowledge Base
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
