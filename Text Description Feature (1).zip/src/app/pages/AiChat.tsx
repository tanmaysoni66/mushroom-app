import { useState, useRef, useEffect } from 'react';
import { Send, User, Thermometer, Bug, Leaf, TrendingUp, Loader2 } from 'lucide-react';
import clsx from 'clsx';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';

type Message = {
  id: string;
  role: 'user' | 'ai';
  content: string | JSX.Element;
  timestamp: Date;
};

// Use the API Key provided in requirements
const GEMINI_API_KEY = "AIzaSyC1hDrB_LUmHPpao6YealtIiGoBCxqo5ys";

export const AiChat = () => {
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'ai',
      content: "Hello! I'm your AI Mushroom Farming Advisor powered by Google Gemini. I can help you with temperature needs, troubleshooting diseases (like green mold), economics, or substrate preparation. How can I assist your farm today?",
      timestamp: new Date()
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const generateGeminiResponse = async (prompt: string) => {
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: `You are an expert AI assistant for an Indian Mushroom Farming Training Platform. Answer the following user question concisely and professionally: ${prompt}` }]
          }]
        })
      });

      if (!response.ok) {
        throw new Error('API request failed');
      }

      const data = await response.json();
      return data.candidates[0].content.parts[0].text;
    } catch (error) {
      console.error(error);
      return "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later or check your internet connection.";
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userText = input;
    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: userText, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const aiText = await generateGeminiResponse(userText);
    
    setMessages(prev => [...prev, {
      id: (Date.now() + 1).toString(),
      role: 'ai',
      content: aiText,
      timestamp: new Date()
    }]);
    setIsTyping(false);
  };

  const quickActions = [
    { label: 'Types of Mushrooms', icon: <Leaf className="w-4 h-4" /> },
    { label: 'Green Mold Fix', icon: <Bug className="w-4 h-4" /> },
    { label: 'Temperature Guide', icon: <Thermometer className="w-4 h-4" /> },
    { label: 'Farming Costs', icon: <TrendingUp className="w-4 h-4" /> },
  ];

  return (
    <div className="flex flex-col h-full absolute inset-0 text-gray-100">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-xl border-b border-white/10 p-4 flex items-center gap-4 shrink-0 z-20 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
        <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-2xl flex items-center justify-center text-white shadow-[0_0_15px_rgba(16,185,129,0.4)] border border-white/20">
          <Leaf className="w-6 h-6" />
        </div>
        <div>
          <h1 className="font-bold text-lg text-white leading-tight">AI Farming Advisor</h1>
          <p className="text-xs text-emerald-400 font-medium flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,1)]"></span> 
            Powered by Gemini
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-3 shrink-0 flex gap-3 overflow-x-auto no-scrollbar border-b border-white/5 bg-black/20 backdrop-blur-md z-10">
        {quickActions.map(action => (
          <button 
            key={action.label}
            onClick={() => setInput(action.label)} 
            className="whitespace-nowrap bg-white/5 border border-white/10 px-4 py-2 rounded-xl text-sm font-medium text-gray-300 hover:bg-white/10 hover:text-white transition-colors flex items-center gap-2"
          >
            {action.icon} {action.label}
          </button>
        ))}
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-32">
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div 
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={clsx("flex gap-3 max-w-[85%]", msg.role === 'user' ? "ml-auto flex-row-reverse" : "")}
            >
              <div className={clsx(
                "w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-lg border",
                msg.role === 'ai' 
                  ? "bg-gradient-to-br from-emerald-500 to-teal-600 border-emerald-400/50 text-white" 
                  : "bg-gray-800 border-gray-600 text-gray-300"
              )}>
                {msg.role === 'ai' ? <Leaf className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>
              
              <div className="flex flex-col gap-1">
                <div className={clsx(
                  "p-4 rounded-2xl text-sm leading-relaxed shadow-lg backdrop-blur-md border",
                  msg.role === 'user' 
                    ? "bg-emerald-600 text-white rounded-tr-sm border-emerald-500/50" 
                    : "bg-white/10 text-gray-100 rounded-tl-sm border-white/10"
                )}>
                  {typeof msg.content === 'string' ? (
                    <div className="whitespace-pre-wrap">{msg.content.replace(/\*\*/g, '')}</div>
                  ) : msg.content}
                </div>
                <span className={clsx(
                  "text-[10px] text-gray-500 font-medium",
                  msg.role === 'user' ? "text-right mr-1" : "ml-1"
                )}>
                  {format(msg.timestamp, 'h:mm a')}
                </span>
              </div>
            </motion.div>
          ))}
          
          {isTyping && (
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="flex gap-3 max-w-[85%]"
            >
              <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-lg border bg-gradient-to-br from-emerald-500 to-teal-600 border-emerald-400/50 text-white">
                <Leaf className="w-4 h-4" />
              </div>
              <div className="p-4 rounded-2xl text-sm leading-relaxed shadow-lg backdrop-blur-md border bg-white/10 text-gray-100 rounded-tl-sm border-white/10 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                <span className="text-gray-400">Gemini is thinking...</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="fixed bottom-24 left-0 w-full px-4 z-40">
        <form onSubmit={handleSend} className="max-w-4xl mx-auto flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isTyping}
            placeholder="Ask about mushroom farming..."
            className="flex-1 bg-gray-900/90 backdrop-blur-xl border border-white/10 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/50 rounded-2xl px-5 py-4 text-sm text-white transition-all shadow-[0_8px_32px_rgba(0,0,0,0.5)] placeholder-gray-500 outline-none disabled:opacity-50"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isTyping}
            className="bg-emerald-500 text-white p-4 rounded-2xl hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)]"
          >
            <Send className="w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
};
