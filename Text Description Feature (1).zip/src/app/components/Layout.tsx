import { Outlet, NavLink } from 'react-router';
import { Home, User, Settings, LogOut, Moon, Sun, BookOpen, MessageCircle, Leaf } from 'lucide-react';
import { useAppStore } from '../store';
import clsx from 'clsx';
import { motion, AnimatePresence } from 'motion/react';

export const Layout = () => {
  const { theme, toggleTheme, logout } = useAppStore();

  const navLinks = [
    { to: '/dashboard', icon: <Home className="w-6 h-6" />, label: 'Home' },
    { to: '/ai-chat', icon: <Leaf className="w-6 h-6" />, label: 'AI Advisor', isAi: true },
    { to: '/profile', icon: <User className="w-6 h-6" />, label: 'Profile' },
  ];

  // We enforce a dark-glassy immersive theme globally for the 3D aesthetic
  return (
    <div className="flex h-screen bg-[#0A100D] text-gray-100 font-sans overflow-hidden relative selection:bg-emerald-500/30">
      
      {/* 3D Ambient Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-emerald-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-amber-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Content Area */}
      <main className="flex-1 w-full h-full relative z-10">
        <div className="h-full overflow-y-auto w-full pb-32 no-scrollbar">
          <Outlet />
        </div>
      </main>

      {/* Modern Floating Navigation Bar */}
      <div className="fixed bottom-6 left-0 w-full px-6 flex justify-center z-50 pointer-events-none">
        <nav className="pointer-events-auto bg-white/5 backdrop-blur-xl border border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.4)] rounded-full px-4 py-3 flex items-center gap-6 md:gap-12 relative overflow-hidden">
          {/* subtle inner glow */}
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/10 to-transparent pointer-events-none rounded-full" />
          
          {navLinks.map((link) => {
            const isAi = link.isAi;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                className={({ isActive }) => clsx(
                  "relative flex flex-col items-center gap-1 p-2 rounded-2xl transition-all duration-300 z-10",
                  isActive 
                    ? (isAi ? "text-emerald-400" : "text-white") 
                    : "text-gray-400 hover:text-gray-200",
                  isAi ? "transform -translate-y-2" : ""
                )}
              >
                {({ isActive }) => (
                  <>
                    {isAi ? (
                      <div className={clsx(
                        "w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all duration-300 border",
                        isActive 
                          ? "bg-emerald-500 text-white shadow-emerald-500/50 border-emerald-400" 
                          : "bg-emerald-900/50 text-emerald-400 border-emerald-500/30 backdrop-blur-md"
                      )}>
                        {link.icon}
                        {isActive && (
                          <motion.div 
                            layoutId="nav-indicator-ai"
                            className="absolute inset-0 rounded-full bg-emerald-400/20 blur-md -z-10"
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ repeat: Infinity, duration: 2 }}
                          />
                        )}
                      </div>
                    ) : (
                      <>
                        {link.icon}
                        {isActive && (
                          <motion.div 
                            layoutId="nav-indicator"
                            className="absolute -bottom-2 w-1.5 h-1.5 rounded-full bg-emerald-400"
                          />
                        )}
                      </>
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>
    </div>
  );
};
