import React, { createContext, useContext, useState, useEffect } from 'react';
import { MOCK_LESSONS, Lesson } from './data';

export type User = {
  name: string;
  email: string;
  studentId: string;
  registeredAt: number;
  role: 'admin' | 'user';
  progress?: string[];
};

type AppState = {
  user: User | null;
  theme: 'light' | 'dark';
  progress: string[];
  lessons: Lesson[];
  login: (user: User) => void;
  logout: () => void;
  toggleTheme: () => void;
  markCompleted: (lessonId: string) => void;
  updateLesson: (lessonId: string, updates: Partial<Lesson>) => void;
};

const AppContext = createContext<AppState | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark'); // Default to dark for 3D UI
  const [progress, setProgress] = useState<string[]>([]);
  const [lessons, setLessons] = useState<Lesson[]>(() => {
    const saved = localStorage.getItem('omf_lessons');
    return saved ? JSON.parse(saved) : MOCK_LESSONS;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  // Persist lessons
  useEffect(() => {
    localStorage.setItem('omf_lessons', JSON.stringify(lessons));
  }, [lessons]);

  // Persist user progress
  useEffect(() => {
    if (user && user.role === 'user') {
      const usersStr = localStorage.getItem('omf_users');
      if (usersStr) {
        let users = JSON.parse(usersStr);
        users = users.map((u: any) => u.email === user.email ? { ...u, progress } : u);
        localStorage.setItem('omf_users', JSON.stringify(users));
      }
    }
  }, [progress, user]);

  const login = (userData: User) => {
    setUser(userData);
    setProgress(userData.progress || []);
  };
  
  const logout = () => {
    setUser(null);
    setProgress([]);
  };

  const toggleTheme = () => setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  
  const markCompleted = (lessonId: string) => {
    if (!progress.includes(lessonId)) {
      setProgress(prev => [...prev, lessonId]);
    }
  };

  const updateLesson = (lessonId: string, updates: Partial<Lesson>) => {
    setLessons(prev => prev.map(l => l.id === lessonId ? { ...l, ...updates } : l));
  };

  return (
    <AppContext.Provider value={{ user, theme, progress, lessons, login, logout, toggleTheme, markCompleted, updateLesson }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppStore = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppStore must be used within AppProvider');
  return context;
};
