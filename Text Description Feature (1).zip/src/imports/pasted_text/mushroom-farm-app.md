Create a modern, professional **mobile application with a secure Admin Dashboard** for an Online Mushroom Farming Training Platform.

The application must support **two access roles: Admin and Normal Users** with strict role-based authentication.

1. Authentication System

• Normal users should only access the **Course Dashboard**.
• The **Admin Dashboard must remain hidden** from normal users.
• When the admin logs in, the system should automatically open the **Admin Dashboard**.

Admin Credentials
User ID: organicmushroomfarm
Password: Sonib491@

2. Admin Dashboard Features

User Management
• View all registered users
• Show user name, email, login history, and course progress
• Display course completion percentage
• Block or remove users if required
• Monitor active users and login activity

Video Lesson Management
• Edit, replace, or update video lessons
• Videos embedded using **Google Drive links**
• Currently there are **3 lessons available**
• Lesson 4 should display **“Coming Soon”**
• Admin must be able to upload or activate Lesson 4 anytime

PDF Lesson Management
• Upload new PDF lessons
• Edit or delete PDFs
• PDFs automatically appear in the student learning section

3. AI Chatbot Integration (Google Gemini)

Integrate a **Mushroom Farming AI Assistant** powered by **Google Gemini API**.

Gemini API Configuration

API Key:
AIzaSyC1hDrB_LUmHPpao6YealtIiGoBCxqo5ys

Requirements:

• The chatbot should answer mushroom farming questions
• Support topics like oyster mushroom cultivation, humidity, temperature, setup cost, spawn preparation, and marketing
• Connect the chatbot backend to **Google Gemini API** using the provided API key
• Create an endpoint `/ai-chat` that sends user questions to Gemini and returns the generated response

Admin AI Training Panel

Inside the Admin Dashboard include controls to:

• Add new questions and answers
• Upload mushroom farming knowledge PDFs
• Improve chatbot responses
• Update AI knowledge base

4. User Analytics

Admin dashboard should display:

• Total registered users
• Active users
• Course completion statistics
• Lesson progress tracking

5. Social Media Integration

Add social media buttons linking to:

Instagram
http://instagram.com/organic_mushroom_farm_jabalpur

Facebook
https://www.facebook.com/@organic.mushroom.farm0/

YouTube
https://m.youtube.com/@organicmushroomfarm

Pinterest
https://www.pinterest.com/organicmushroomfarm/

6. UI Design

• Modern **3D dashboard interface**
• **Glassmorphism design style**
• Nature-inspired color palette (green, white, earthy brown)
• Mushroom-themed icons
• Floating cards with soft shadows
• Clean mobile-first layout

7. Security

• Admin panel must only appear when admin credentials are used
• Normal users must never access admin features
• Protect routes and secure authentication

The final application should feel **modern, professional, and easy to manage**, designed for delivering a **high-quality mushroom farming online training platform with integrated AI support**.
