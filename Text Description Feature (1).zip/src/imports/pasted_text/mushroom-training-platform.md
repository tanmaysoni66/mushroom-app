Create a professional mobile-friendly online training platform.
App Name:
Organic Mushroom Farm
Design Theme:
Use a modern agriculture theme with purple and mushroom-inspired colors.
Primary color: Purple
Secondary colors: Mushroom beige / earthy brown / light cream.
The interface should look clean, modern and professional like an online education platform.
________________________________________
Branding
Allow the admin to upload the company logo on the login page and dashboard.
________________________________________
1.	Login and Signup System
Create a login and signup page.
Signup form fields:
Full Name
Email Address
Password

If the user does not upload a photo, show a default profile icon.
After signup automatically generate a unique Student ID.
Example format:
OMF-0001
OMF-0002
OMF-0003
Display the Student ID in the profile and dashboard.
Only logged-in users can access the training course.
________________________________________
2.	Login Security
3.	User Profile Page
Display:
Full Name
Email
Student ID
Profile Photo
Course Progress Percentage
________________________________________
4.	Dark Mode
Add Light Mode and Dark Mode toggle.
________________________________________
5.	Course Instructions
Display this message before training begins:
Please log in using the same browser where you received the login link on WhatsApp.
The class will start at 4:00 PM.
After completing the lesson click Mark as Completed.
Next lesson will unlock automatically the next day at 4:00 PM.
________________________________________
6.	Live Training System
Each lesson starts automatically at 4:00 PM.
From 4:00 PM to 5:30 PM the video behaves like a live class.
During live session:
Users cannot pause
Users cannot skip
After 5:30 PM:
Students can watch the recording anytime.
________________________________________
7.	Course Dashboard
Title:
Organic Mushroom Farm – Online Mushroom Farming Training
Display lessons in order.
________________________________________
Lesson 1
Title:
Mushroom Training Online Course
Video:
https://drive.google.com/file/d/1t4CVmAtS6SVOxewXhq-zY69BJuE0m30Y/preview
Live Start:
4:00 PM
Live End:
5:30 PM
After completing Lesson 1 unlock PDF Notes Section.
English Guide:
https://docs.google.com/document/d/1SQuzj_dGlLClISSywYx7CfAGC6-jsOuPLPS2VBi04-k/edit
Hindi Guide:
https://docs.google.com/document/d/1-B86jDfaHPGMVXgnB4pUbITnI0B9mgy9gaCYEzLTGl4/edit
________________________________________
Lesson 2
Title:
Button Mushroom Full Cultivation Process
Video:
https://drive.google.com/file/d/1lSPWvPU33n9eRRzjS2kER07cZYtzetID/preview
Unlock Time:
Next day 4:00 PM
After completing Lesson 2 unlock PDF Notes.
English Guide:
https://docs.google.com/document/d/10O9X2Dz7rr3tiFLcsNxEjhBJ4c_voBi35CB4iaVxcNA/edit
Hindi Guide:
https://docs.google.com/document/d/1-deLiorpAHZ0K4VKU0GEo7z0-SG0KzO94Dym9WQlnfc/edit
________________________________________
Lesson 3
Title:
Oyster Mushroom Full Cultivation Process
Video:
https://drive.google.com/file/d/1mUEaQX_m5Cn0rhiE2px5Yr894XZ40gsr/preview
Unlock Time:
Two days later 4:00 PM
After completing Lesson 3 unlock Advanced Guide PDFs.
English Guide:
https://docs.google.com/document/d/10zKIme_lLJIeEz8rF3kTpk3U1SpXTjaPCAKF6gyRlgg
Hindi Guide:
https://docs.google.com/document/d/111ejEhBsZKFH66f97Ke2CliFIxecScYZiyD-gJYdCsE/edit
________________________________________
Lesson 4
Title:
Milky Mushroom Farming Guide
Status:
Coming Soon
English Guide:
https://docs.google.com/document/d/11ZraZgj3OSIy03xTvhprZe5RFhsiGBz7IxnmzW9Cxtw/edit
Hindi Guide:
https://docs.google.com/document/d/11E-cE1JSN_gEmjT6QT2gxND1lAqP9O-t45YQi-aKvYs/edit
This lesson will appear after Lesson 3 is completed.
________________________________________
8.	Progress Tracking
Add a course progress bar.
Users must mark lessons as completed.
________________________________________
9.	Course Completion Message
When the student finishes all lessons show message:
Congratulations 🎉
You have successfully completed the Organic Mushroom Farm Training Course.
We hope this training helps you start your own mushroom farming business.
________________________________________
10.	Admin Panel
Admin can:
Add videos
Edit lessons
Delete lessons
View registered students
View Student ID list
________________________________________
11.	Support
Support Phone:
9203544140
Buttons:
Call Support
Message Support
________________________________________
12.	Email Support
Users can send email to:
sonib491@gmail.com
________________________________________
13.	Social Media
Instagram
https://www.instagram.com/organic_mushroom_farm_jabalpur
Facebook
https://www.facebook.com/organic.mushroom.farm0
YouTube
https://www.youtube.com/@organicmushroomfarm
Pinterest
https://www.pinterest.com/organicmushroomfarm
________________________________________
Design Style
Modern purple mushroom-themed education platform with clean dashboard, smooth video player and mobile optimized layout.

