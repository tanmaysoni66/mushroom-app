Update the existing Organic Mushroom Farm training app with the following improvements.

---

1. Remove Admin Panel

Remove the Admin Panel feature completely from the platform.

The app should only contain:

Dashboard
Course Lessons
PDF Notes
AI Mushroom Assistant
Support
Profile

No admin dashboard or admin control panel should appear anywhere in the app.

---

2. Update Login Page Text

Remove the following text completely:

"Sign in to your account"
"Or start your 14-day free trial"

Replace it with a simple and clear message:

Title:
Organic Mushroom Farm Training

Subtitle:
Learn professional mushroom farming step by step.

Primary Button:
Create a New Account

Secondary Button:
Login

---

3. Improve AI Feature (Mushroom Farming AI Expert)

Create an advanced AI assistant called:

Mushroom Farming AI Expert

Add a button on the dashboard:

Ask Mushroom AI

The AI assistant should work like a **complete mushroom farming guide** helping farmers with all types of mushroom cultivation.

---

4. AI Mushroom Knowledge System

The AI should provide guidance for different mushrooms including:

Oyster Mushroom
Button Mushroom
Milky Mushroom
Shiitake Mushroom
Paddy Straw Mushroom
Ganoderma Mushroom

---

5. AI Temperature Guide

The AI should calculate ideal temperatures for different stages.

Example:

Oyster Mushroom
Spawn running temperature: 22°C – 26°C
Fruiting temperature: 18°C – 22°C

Button Mushroom
Spawn running temperature: 23°C – 25°C
Fruiting temperature: 14°C – 18°C

Milky Mushroom
Spawn running temperature: 25°C – 30°C
Fruiting temperature: 28°C – 32°C

---

6. AI Humidity Guide

The AI should recommend humidity levels.

Example:

Spawn running humidity: 70% – 75%
Fruiting humidity: 80% – 90%

---

7. Spawn Calculation Tool

Add a calculator inside the AI system.

Users can enter:

Number of bags
Bag weight (kg)

AI should calculate:

Required spawn quantity

Example:

1 kg substrate bag = 20–30 grams spawn
10 bags = 200–300 grams spawn

---

8. Water Calculation Tool

AI should help farmers calculate water requirements.

Example:

If substrate moisture should be 60–65%, AI calculates the correct amount of water needed.

Example output:

For 10 kg dry substrate
Water required ≈ 6 to 6.5 liters

---

9. Substrate Mixing Guide

AI should guide the user on how to prepare substrate mixtures.

Examples:

Wheat straw
Paddy straw
Sawdust
Corn cob

Provide step-by-step mixing instructions.

---

10. Mushroom Room Setup Guide

AI should guide how to create a growing room.

Topics:

Room temperature control
Humidity management
Ventilation system
Rack setup

---

11. Contamination Detection

AI should help users diagnose problems.

Example questions:

Why is green mold appearing?

Why are mushrooms turning yellow?

Why are mushrooms small?

The AI should provide beginner-friendly solutions.

---

12. Daily Mushroom Tips

Show a daily farming tip on the dashboard.

Example:

"Mushroom Tip: Maintain 80–90% humidity during fruiting stage for healthy mushroom growth."

---

13. AI Chat Interface

Design a simple mobile-friendly chat interface.

Example user question:

How much spawn is required for 20 bags?

Example AI response:

For 20 substrate bags of 1 kg each, you will need approximately 400–600 grams of mushroom spawn.

---

14. Smart Farming Tools

Add additional AI tools:

Spawn calculator
Humidity guide
Temperature guide
Substrate preparation guide
Mushroom disease guide

---

15. Design

The AI feature should look modern and professional.

Add a mushroom icon and AI chat button on the dashboard:

Button label:
Ask Mushroom AI

The AI should behave like a **professional mushroom farming expert helping beginners start and manage mushroom cultivation easily**.
