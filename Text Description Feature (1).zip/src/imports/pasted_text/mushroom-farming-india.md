Mushroom Farming Knowledge Base for AI Assistant (India)

1. Types of Mushrooms in India

The AI assistant should understand the different types of mushrooms grown in India and the conditions required for each.

Oyster Mushroom (Dhingri)
	•	Oyster mushroom is the easiest and most economical mushroom to cultivate.
	•	It is highly recommended for beginners.
	•	Required temperature: 20°C – 30°C.
	•	It can be grown throughout the year but performs best in moderate climates.

Button Mushroom
	•	Button mushroom has the highest market demand in India.
	•	It requires technical knowledge and controlled environmental conditions.
	•	Required temperature: 15°C – 22°C.
	•	Usually grown during winter or inside temperature-controlled rooms.

Milky Mushroom
	•	Milky mushroom is ideal for hot climates.
	•	It is widely cultivated in warmer regions.
	•	Required temperature: 30°C – 35°C.

Paddy Straw Mushroom
	•	This mushroom is grown mainly on paddy straw (rice straw).
	•	It has a short production cycle but good market demand.

⸻

2. Basic Requirements for Mushroom Farming

Space
	•	A closed room, shed, or simple structure made with bamboo or jute.
	•	The area should allow control over temperature, humidity, and ventilation.

Substrate (Raw Material)

Common substrates used include:
	•	Wheat straw
	•	Paddy straw

Mushroom Seeds (Spawn)
	•	Always purchase high-quality spawn from reliable laboratories.

Environmental Control

To maintain proper growing conditions, the following equipment may be used:
	•	Humidifier
	•	Water spray pump
	•	Exhaust fan

⸻

3. Step-by-Step Mushroom Cultivation Process

Step 1: Substrate Preparation

The straw must be sterilized to remove pests and unwanted fungi.

Chemical Treatment Method

Mix the following in 100 liters of water:
	•	10–12 kg straw
	•	100–150 ml Formalin
	•	10–15 grams Bavistin

Soak the straw for 12–18 hours.

Hot Water Treatment Method
	•	Boil the straw in 80–90°C hot water for 1 hour.

Drying
	•	After treatment, drain the straw and dry it in shade.
	•	Final moisture level should be 60–70%.

⸻

Step 2: Spawning (Mixing Mushroom Seeds)
	•	Mix mushroom spawn evenly with the prepared straw.
	•	Use approximately 100 grams of spawn per 1 kg of dry straw.
	•	Fill the mixture into 16 × 18 inch transparent polythene bags.
	•	Make small holes in the bags for air exchange.

⸻

Step 3: Incubation
	•	Place the bags in a dark room for 15–20 days.
	•	During this period, the spawn spreads throughout the straw.
	•	The straw gradually becomes completely white.
	•	This stage is called the Mycelium Run.

⸻

Step 4: Pinning and Fruiting
	•	Once the bag is fully white, cut open the polythene bag or enlarge the holes.
	•	Allow fresh air and mild light into the room.
	•	Spray water 2–3 times daily to maintain humidity.
	•	Maintain humidity at 80–90%.

Small mushrooms called pins will start appearing within 5–7 days.

⸻

Step 5: Harvesting
	•	Harvest mushrooms when they reach full size but before the edges start curling.
	•	Gently twist and pull the mushrooms for harvesting.
	•	Each bag can produce mushrooms about 3 times (3 flushes).

⸻

4. Common Problems and Solutions

The AI assistant should be able to troubleshoot common issues faced by farmers.

Green Mold

Symptoms:
	•	Green fungus appearing on the bag.

Cause:
	•	Poor hygiene or contamination.

Solution:
	•	Remove the infected bag immediately to prevent spread.

⸻

Flies or Insects

Prevention:
	•	Install mesh doors or insect nets.
	•	Spray neem oil around doors and windows.

⸻

Long Stem and Small Cap

Cause:
	•	High carbon dioxide (CO₂) levels in the growing room.

Solution:
	•	Improve ventilation.
	•	Use exhaust fans to bring fresh air.

⸻

5. Economics and Marketing

Investment

Small Oyster Mushroom Setup (10 × 10 ft room):
₹5,000 – ₹10,000

Button Mushroom Setup:
₹2,00,000 – ₹5,00,000

⸻

Production
	•	From 1 kg of straw, farmers can produce approximately 600–800 grams of oyster mushrooms.

⸻

Market Price
	•	Mushrooms usually sell for ₹150 – ₹250 per kg, depending on location and quality.

⸻

Government Subsidies

Government schemes and agricultural departments in India provide 40–50% subsidy for mushroom farming through horticulture programs.

⸻

6. Value Added Products

If fresh mushrooms are not sold immediately, they can be processed into:
	•	Dried mushrooms
	•	Mushroom powder
	•	Mushroom pickle
	•	Mushroom papad

These products often sell at higher profit margins.

⸻

7. AI Assistant – Frequently Asked Questions (FAQs)

Q: Why are my mushrooms turning yellow?

Answer:
This usually happens due to low humidity or high temperature. Increase humidity in the growing room and spray water lightly.

⸻

Q: Do I need farmland to grow mushrooms?

Answer:
No. Mushroom farming can be done in closed rooms, sheds, or basements using vertical rack systems.

⸻

Q: Where can I buy mushroom spawn?

Answer:
Mushroom spawn can be purchased from:
	•	Krishi Vigyan Kendra (KVK)
	•	Agricultural Universities
	•	Government-approved laboratories